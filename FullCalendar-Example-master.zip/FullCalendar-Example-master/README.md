# FullCalendar Example

## 기능 :+1:
- 월/주/일/목록별 view
- 주말 보이기/숨기기
- 날짜 클릭으로 새로운 일정 등록
- 일정별 색상 등록
- 기존일정 클릭시 팝업을 통한 수정, 삭제
- 드래그, 리사이즈를 이용한 날짜 수정
- 일정 hover시 팝업
- 카테고리, 등록자를 통한 일정 필터링
---
- ## [DEMO PAGE IS HERE](https://saintsilver.github.io/FullCalendar-Example)
![스크린샷](/image/demo.png)

