# bimProject-How to use Project

> explain how to use this [project](https://github.com/liante0904/bimProject).
## How to import this project
### IDE
  - [IntelliJ](https://liante0904.tistory.com/191)
  - [Eclipse(STS)](https://liante0904.tistory.com/121)
### DataBase
 **Administrator account information**
 > ID : admin
 
 > Password : admin1234    
  - [Import Database Query](https://github.com/liante0904/bimProject/blob/master/src/main/resources/config/spring/bridgeimpact_dataBase_import_query.sql)
### Properties
  - [env.properties](https://github.com/liante0904/bimProject/blob/master/src/main/resources/config/spring/env.properties.sample)
    1. You must write values in .properties file.
    2. Delete first line in file.
    3. And Rename to **env.properties** 
    